name=input("what is your age?")
nn=int(name)+6
print(nn)
